<?php

/**
 * The admin-specific functionality of the plugin.
 */
class Rena_Multistore_Admin {

    /**
     * Initialize the class and set its properties.
     */
    public function __construct() {
        // Constructor
    }

    /**
     * Register the stylesheets for the admin area.
     */
    public function enqueue_styles() {
        wp_enqueue_style(
            'rena-multistore-admin',
            RENA_MULTISTORE_PLUGIN_URL . 'admin/css/rena-multistore-admin.css',
            array(),
            RENA_MULTISTORE_VERSION,
            'all'
        );
    }

    /**
     * Register the JavaScript for the admin area.
     */
    public function enqueue_scripts() {
        wp_enqueue_script(
            'rena-multistore-admin',
            RENA_MULTISTORE_PLUGIN_URL . 'admin/js/rena-multistore-admin.js',
            array('jquery'),
            RENA_MULTISTORE_VERSION,
            false
        );
    }

    /**
     * Add menu items to the admin area.
     */
    public function add_menu_pages() {
        add_menu_page(
            __('Rena Multistore', 'rena-multistore'),
            __('Rena Multistore', 'rena-multistore'),
            'manage_options',
            'rena-multistore',
            array($this, 'display_plugin_main_page'),
            'dashicons-store',
            56
        );
    }

    /**
     * Display the main plugin admin page.
     */
    public function display_plugin_main_page() {
        require_once RENA_MULTISTORE_PLUGIN_DIR . 'admin/partials/rena-multistore-admin-display.php';
    }
} 