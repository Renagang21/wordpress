<?php

/**
 * Fired during plugin activation.
 */
class Rena_Multistore_Activator {

    /**
     * Initialize plugin on activation.
     */
    public static function activate() {
        // Create necessary database tables
        self::create_tables();

        // Set default options
        self::set_default_options();
    }

    /**
     * Create necessary database tables.
     */
    private static function create_tables() {
        global $wpdb;
        $charset_collate = $wpdb->get_charset_collate();

        // Example table creation (customize as needed)
        $sql = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}rena_multistore_stores (
            id bigint(20) NOT NULL AUTO_INCREMENT,
            store_name varchar(255) NOT NULL,
            store_address text,
            store_phone varchar(50),
            created_at datetime DEFAULT CURRENT_TIMESTAMP,
            updated_at datetime DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            PRIMARY KEY  (id)
        ) $charset_collate;";

        require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
        dbDelta($sql);
    }

    /**
     * Set default plugin options.
     */
    private static function set_default_options() {
        $default_options = array(
            'rena_multistore_version' => RENA_MULTISTORE_VERSION,
            'rena_multistore_settings' => array(
                'enabled' => true,
                'default_store' => 1
            )
        );

        foreach ($default_options as $option_name => $option_value) {
            if (get_option($option_name) === false) {
                add_option($option_name, $option_value);
            }
        }
    }
} 