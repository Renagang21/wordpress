<?php
/**
 * The public-facing functionality of the plugin.
 */
class Rena_Multistore_Public {

    public function __construct() {
        // 공개 영역 초기화 코드
    }

    public function enqueue_styles() {
        wp_enqueue_style(
            'rena-multistore-public',
            RENA_MULTISTORE_PLUGIN_URL . 'public/css/rena-multistore-public.css',
            array(),
            RENA_MULTISTORE_VERSION,
            'all'
        );
    }

    public function enqueue_scripts() {
        wp_enqueue_script(
            'rena-multistore-public',
            RENA_MULTISTORE_PLUGIN_URL . 'public/js/rena-multistore-public.js',
            array('jquery'),
            RENA_MULTISTORE_VERSION,
            false
        );
    }
}